Arduino Sketch for the GMSN! Pure Sequencer

Alternate firmware for playing patterns from the gate outputs.

The rate control changes between 8 different patterns, each 32 bars long.
direction control => left = 8 bars forward, middle = random, right=32 bar forward

Reset is now on the first beat (as opposed to the last in the original firmware). Gate 8 output has a single pulse on note 1, so can be used as a reset - this is on all patterns)

Use at your own peril.
And do study the code, and go in and create your own patterns.


I suggest keeping a copy of the original firmware to hand.
