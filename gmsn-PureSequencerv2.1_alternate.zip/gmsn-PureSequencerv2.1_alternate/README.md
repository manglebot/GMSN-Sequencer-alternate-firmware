# GMSN! SDIY Files.

GMSN! Pure Modular Code

Pure ADSR
Pure Quantiser
Pure Sequencer

License
cc-by-4.0 By: Rob Spencer (rob@gmsn.co.uk)
