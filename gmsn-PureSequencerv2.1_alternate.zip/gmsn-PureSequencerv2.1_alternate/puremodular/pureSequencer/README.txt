Arduino Sketch for the GMSN! Pure Sequencer

Alternate firmware for playing patterns from the gate outputs.

Use at your own peril.

I suggest keeping a copy of the original firmware to hand.